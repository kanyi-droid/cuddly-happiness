<?php
    $dbuser="id21166444_wp_d531f61307fb7378d580dc3f4217cecf";
    $dbpass="Nelly@07";
    $host="localhost";
    $db="iid21166444_wp_2b04f27cec917b49a60f5cd698607575";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
// ?>
<?php
    // $dbuser="root";
    // $dbpass="";
    // $host="localhost";
    // $db="elibrary";
    // $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>
