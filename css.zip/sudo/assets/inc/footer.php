<footer id="footer">
         &copy; 2023-<?php echo date('Y');?> eLibrary - InterGrated Library Management System.
         All rights reserved.
</footer>