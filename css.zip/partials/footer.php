<footer class="black-bg text-white">
    <div class="space-60"></div>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-4">
                <a href="#"><img src="images/logo.png" alt="library"></a>
                <div class="space-20"></div>
                <p>Digital eLibrary system</p>
           
             
            </div>
            <div class="col-xs-12 col-sm-4 col-md-3 col-md-offset-1">
                <h4 class="text-white">Contact Us</h4>
                <div class="space-20"></div>
                <table class="table border-none addr-dt">
                    <tr>
                        <td><i class="icofont icofont-social-google-map"></i></td>
                        <td><address>127.0.0.1 Localhost</address></td>
                    </tr>
                    <tr>
                        <td><i class="icofont icofont-email"></i></td>
                        <td>info@library.org</td>
                    </tr>
                    
                </table>
            </div> 
        </div>
    </div>
    <div class="space-60"></div>
</footer>